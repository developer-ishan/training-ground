package tiktaktoe.game;

public enum Cell {
  X, O, E
}
