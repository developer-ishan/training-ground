package com.example.landon_hotel;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LandonHotelApplicationTests {

	@Test
	void contextLoads() {
	}

}
